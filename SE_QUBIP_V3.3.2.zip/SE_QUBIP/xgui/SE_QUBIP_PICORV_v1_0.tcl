
# Loading additional proc with user specified bodies to compute parameter values.
source [file join [file dirname [file dirname [info script]]] gui/SE_QUBIP_PICORV_v1_0.gtcl]

# Definitional proc to organize widgets for parameters.
proc init_gui { IPINST } {
  #Adding Group
  set Interface_Configuration [ipgui::add_group $IPINST -name "Interface Configuration"]
  set IMP_I2C [ipgui::add_param $IPINST -name "IMP_I2C" -parent ${Interface_Configuration}]
  set_property tooltip {Choose between I2C or AXI-4 Lite interfaces} ${IMP_I2C}
  ipgui::add_param $IPINST -name "DEVICE_ADDRESS" -parent ${Interface_Configuration}

  #Adding Group
  set Device_Configuration [ipgui::add_group $IPINST -name "Device Configuration" -layout horizontal]
  ipgui::add_param $IPINST -name "DEVICE" -parent ${Device_Configuration} -widget comboBox
  ipgui::add_param $IPINST -name "TOTAL_MEM" -parent ${Device_Configuration}
  set AVAILABLE_MEM [ipgui::add_param $IPINST -name "AVAILABLE_MEM" -parent ${Device_Configuration}]
  set_property tooltip {(Total Memory) - (On-Chip Memory) - (FIFOs Memory)  - (MLKEM Memory) - (TRNG Memory)} ${AVAILABLE_MEM}

  #Adding Group
  set PicoRV32_Core_Configuration [ipgui::add_group $IPINST -name "PicoRV32 Core Configuration"]
  #Adding Group
  set ISA_Extensions [ipgui::add_group $IPINST -name "ISA Extensions" -parent ${PicoRV32_Core_Configuration} -layout horizontal]
  set_property tooltip {This group controls which standard RISC-V instruction set extensions are enabled. Enabling them adds functionality but increases logic area.} ${ISA_Extensions}
  set ENABLE_RV32I [ipgui::add_param $IPINST -name "ENABLE_RV32I" -parent ${ISA_Extensions}]
  set_property tooltip {RV32I Base Integer Instruction Set} ${ENABLE_RV32I}
  set ENABLE_RV32M [ipgui::add_param $IPINST -name "ENABLE_RV32M" -parent ${ISA_Extensions}]
  set_property tooltip {Enables the M standard extension for hardware MUL, DIV, and REM instructions. If disabled, these must be emulated in software} ${ENABLE_RV32M}
  set ENABLE_COMPRESSED [ipgui::add_param $IPINST -name "ENABLE_COMPRESSED" -parent ${ISA_Extensions}]
  set_property tooltip {Enables the C standard extension for 16-bit instructions. Improves code density and performance from cache/memory} ${ENABLE_COMPRESSED}

  #Adding Group
  set Core_Performance [ipgui::add_group $IPINST -name "Core Performance" -parent ${PicoRV32_Core_Configuration} -display_name {Performance & Area Tuning} -layout horizontal]
  set_property tooltip {Micro-architectural options to trade-off between speed and logic area.} ${Core_Performance}
  set TWO_CYCLE_ALU [ipgui::add_param $IPINST -name "TWO_CYCLE_ALU" -parent ${Core_Performance}]
  set_property tooltip {Makes most ALU operations take two cycles, further reducing logic area and improving timing closure at the cost of performance.} ${TWO_CYCLE_ALU}
  set TWO_CYCLE_COMPARE [ipgui::add_param $IPINST -name "TWO_CYCLE_COMPARE" -parent ${Core_Performance}]
  set_property tooltip {Makes comparison operations (slt, sltu) take two clock cycles instead of one, saving a small amount of area on the critical path.} ${TWO_CYCLE_COMPARE}
  set BARREL_SHIFTER [ipgui::add_param $IPINST -name "BARREL_SHIFTER" -parent ${Core_Performance}]
  set_property tooltip {Use a fast, multi-bit barrel shifter. If disabled, a slower iterative shifter is used, saving area.} ${BARREL_SHIFTER}
  set ENABLE_FAST_MUL [ipgui::add_param $IPINST -name "ENABLE_FAST_MUL" -parent ${Core_Performance}]
  set_property tooltip {(Requires RV32M) Implements a faster, single-cycle multiplier. Increases area significantly compared to the default iterative multiplier.} ${ENABLE_FAST_MUL}

  #Adding Group
  set Interrupts [ipgui::add_group $IPINST -name "Interrupts" -parent ${PicoRV32_Core_Configuration}]
  set_property tooltip {Configuration for the CPU's interrupt controller} ${Interrupts}
  set ENABLE_IRQ [ipgui::add_param $IPINST -name "ENABLE_IRQ" -parent ${Interrupts}]
  set_property tooltip {Enables the interrupt input (irq) and associated control/status registers (CSRs) for handling external interrupts.} ${ENABLE_IRQ}
  set PROGADDR_IRQ [ipgui::add_param $IPINST -name "PROGADDR_IRQ" -parent ${Interrupts}]
  set_property tooltip {The memory address the processor jumps to when an interrupt is asserted and enabled} ${PROGADDR_IRQ}


  #Adding Group
  set SoC_Memory_Map [ipgui::add_group $IPINST -name "SoC Memory Map" -layout horizontal]
  set_property tooltip {This group defines how the processor and its peripherals fit into the larger system} ${SoC_Memory_Map}
  #Adding Page
  set A [ipgui::add_page $IPINST -name "A" -parent ${SoC_Memory_Map} -display_name {PicoRV32}]
  set_property tooltip {PicoRV32 RAM Memory} ${A}
  set MEM_KIB [ipgui::add_param $IPINST -name "MEM_KIB" -parent ${A} -widget comboBox]
  set_property tooltip {Defines the total size of the on-chip memory in Kilobytes (KB). The value must be a multiple of 16 to ensure efficient use of physical BRAM resources} ${MEM_KIB}
  set MEM_WORDS [ipgui::add_param $IPINST -name "MEM_WORDS" -parent ${A}]
  set_property tooltip {Defines the total size of the on-chip instruction/data memory in 32-bit words. The memory is implemented in steps of 16 KiB for maximum resource efficiency. Therefore, the total size must be a multiple of 4096 words (which corresponds to 16 KiB).} ${MEM_WORDS}
  set MEM_BRAM [ipgui::add_param $IPINST -name "MEM_BRAM" -parent ${A}]
  set_property tooltip {Defines the total size of the on-chip instruction/data memory in number of Blocks of RAM (BRAM). The memory is implemented using 16 KiB blocks each made of 4x36 Kb BRAMS in parallel (RAMB36E1).} ${MEM_BRAM}

  #Adding Page
  set TRNG [ipgui::add_page $IPINST -name "TRNG" -parent ${SoC_Memory_Map}]
  ipgui::add_param $IPINST -name "TRNG_MEM_KIB" -parent ${TRNG} -widget comboBox
  ipgui::add_param $IPINST -name "TRNG_MEM_WORDS" -parent ${TRNG}
  ipgui::add_param $IPINST -name "TRNG_MEM_BRAM" -parent ${TRNG}

  #Adding Page
  set B [ipgui::add_page $IPINST -name "B" -parent ${SoC_Memory_Map} -display_name {Peripherals}]
  set_property tooltip {Peripherals Addresses} ${B}
  set PROGADDR_RESET [ipgui::add_param $IPINST -name "PROGADDR_RESET" -parent ${B}]
  set_property tooltip {The memory address where the processor begins execution after a reset} ${PROGADDR_RESET}
  set PERIPHERALS_BASE_ADDR [ipgui::add_param $IPINST -name "PERIPHERALS_BASE_ADDR" -parent ${B}]
  set_property tooltip {The starting memory-mapped address for the peripheral bus, where accelerators like SHA, AES, etc., will be located.} ${PERIPHERALS_BASE_ADDR}
  set SLH_KECCAK_BASE_ADDR [ipgui::add_param $IPINST -name "SLH_KECCAK_BASE_ADDR" -parent ${B}]
  set_property tooltip {The starting memory-mapped address for the SLHDSA Keccak bus.} ${SLH_KECCAK_BASE_ADDR}
  set SLH_SHA256_BASE_ADDR [ipgui::add_param $IPINST -name "SLH_SHA256_BASE_ADDR" -parent ${B}]
  set_property tooltip {The starting memory-mapped address for the SLHDSA SHA256 bus.} ${SLH_SHA256_BASE_ADDR}
  set SLH_SHA512_BASE_ADDR [ipgui::add_param $IPINST -name "SLH_SHA512_BASE_ADDR" -parent ${B}]
  set_property tooltip {The starting memory-mapped address for the SLHDSA SHA512 bus.} ${SLH_SHA512_BASE_ADDR}


  #Adding Group
  set Cryptographic_Algorithms [ipgui::add_group $IPINST -name "Cryptographic Algorithms" -display_name {Cryptographic Accelerators}]
  set_property tooltip {Enable or disable the custom hardware accelerators} ${Cryptographic_Algorithms}
  #Adding Page
  set Hash_Functions [ipgui::add_page $IPINST -name "Hash Functions" -parent ${Cryptographic_Algorithms}]
  set IMP_SHA2 [ipgui::add_param $IPINST -name "IMP_SHA2" -parent ${Hash_Functions}]
  set_property tooltip {Includes the hardware accelerator for SHA-2 (SHA-256, SHA-382, SHA-512, SHA-512/256) hash functions. It is mandatory to implement for MLDSA and SLHDSA algorithms.} ${IMP_SHA2}
  set IMP_SHA3 [ipgui::add_param $IPINST -name "IMP_SHA3" -parent ${Hash_Functions}]
  set_property tooltip {Includes the hardware accelerator for SHA-3 (SHA3-256, SHA3-512) and SHAKE (SHAKE128, SHAKE256) hashing functions. It is mandatory to implement for MLDSA and SLHDSA algorithms.} ${IMP_SHA3}

  #Adding Page
  set Symmetric_Ciphers [ipgui::add_page $IPINST -name "Symmetric Ciphers" -parent ${Cryptographic_Algorithms}]
  set IMP_AES [ipgui::add_param $IPINST -name "IMP_AES" -parent ${Symmetric_Ciphers}]
  set_property tooltip {Includes the hardware accelerator for the Advanced Encryption Standard (AES-128/192/256)} ${IMP_AES}

  #Adding Page
  set Key_Exchange [ipgui::add_page $IPINST -name "Key Exchange" -parent ${Cryptographic_Algorithms}]
  set IMP_X25519 [ipgui::add_param $IPINST -name "IMP_X25519" -parent ${Key_Exchange}]
  set_property tooltip {Includes the hardware accelerator for X25519 elliptic curve Diffie-Hellman key exchange} ${IMP_X25519}
  set IMP_MLKEM [ipgui::add_param $IPINST -name "IMP_MLKEM" -parent ${Key_Exchange}]
  set_property tooltip {Includes the hardware accelerator for Module-Lattice-based Key Encapsulation Mechanism (MLKEM-512/768/1024)} ${IMP_MLKEM}

  #Adding Page
  set Digital_Signatures [ipgui::add_page $IPINST -name "Digital Signatures" -parent ${Cryptographic_Algorithms}]
  set IMP_EDDSA [ipgui::add_param $IPINST -name "IMP_EDDSA" -parent ${Digital_Signatures}]
  set_property tooltip {Includes the hardware accelerator for Edwards-curve Digital Signature Algorithm (EdDSA) over curve EdDSA25519} ${IMP_EDDSA}
  set IMP_MLDSA [ipgui::add_param $IPINST -name "IMP_MLDSA" -parent ${Digital_Signatures}]
  set_property tooltip {Includes the hardware accelerator for Module-Lattice-based Digital Signature Algorithm (MLDSA-44/65/87)} ${IMP_MLDSA}
  set IMP_SLHDSA [ipgui::add_param $IPINST -name "IMP_SLHDSA" -parent ${Digital_Signatures}]
  set_property tooltip {Includes the hardware accelerator for StateLess-Hash based Digital Signature Algorithm (SLHDSA-SHA2/SHAKE-128/192/256-S/F)} ${IMP_SLHDSA}

  #Adding Page
  set TRNG_IMP [ipgui::add_page $IPINST -name "TRNG_IMP" -parent ${Cryptographic_Algorithms} -display_name {TRNG}]
  set IMP_TRNG [ipgui::add_param $IPINST -name "IMP_TRNG" -parent ${TRNG_IMP}]
  set_property tooltip {Implement RO-based TRNG} ${IMP_TRNG}



}

proc update_PARAM_VALUE.AVAILABLE_MEM { PARAM_VALUE.AVAILABLE_MEM PARAM_VALUE.IMP_MLKEM PARAM_VALUE.TOTAL_MEM PARAM_VALUE.MEM_BRAM PARAM_VALUE.TRNG_MEM_BRAM } {
	# Procedure called to update AVAILABLE_MEM when any of the dependent parameters in the arguments change
	
	set AVAILABLE_MEM ${PARAM_VALUE.AVAILABLE_MEM}
	set IMP_MLKEM ${PARAM_VALUE.IMP_MLKEM}
	set TOTAL_MEM ${PARAM_VALUE.TOTAL_MEM}
	set MEM_BRAM ${PARAM_VALUE.MEM_BRAM}
	set TRNG_MEM_BRAM ${PARAM_VALUE.TRNG_MEM_BRAM}
	set values(IMP_MLKEM) [get_property value $IMP_MLKEM]
	set values(TOTAL_MEM) [get_property value $TOTAL_MEM]
	set values(MEM_BRAM) [get_property value $MEM_BRAM]
	set values(TRNG_MEM_BRAM) [get_property value $TRNG_MEM_BRAM]
	set_property value [gen_USERPARAMETER_AVAILABLE_MEM_VALUE $values(IMP_MLKEM) $values(TOTAL_MEM) $values(MEM_BRAM) $values(TRNG_MEM_BRAM)] $AVAILABLE_MEM
}

proc validate_PARAM_VALUE.AVAILABLE_MEM { PARAM_VALUE.AVAILABLE_MEM } {
	# Procedure called to validate AVAILABLE_MEM
	return true
}

proc update_PARAM_VALUE.DEVICE_ADDRESS { PARAM_VALUE.DEVICE_ADDRESS PARAM_VALUE.IMP_I2C } {
	# Procedure called to update DEVICE_ADDRESS when any of the dependent parameters in the arguments change
	
	set DEVICE_ADDRESS ${PARAM_VALUE.DEVICE_ADDRESS}
	set IMP_I2C ${PARAM_VALUE.IMP_I2C}
	set values(IMP_I2C) [get_property value $IMP_I2C]
	if { [gen_USERPARAMETER_DEVICE_ADDRESS_ENABLEMENT $values(IMP_I2C)] } {
		set_property enabled true $DEVICE_ADDRESS
	} else {
		set_property enabled false $DEVICE_ADDRESS
	}
}

proc validate_PARAM_VALUE.DEVICE_ADDRESS { PARAM_VALUE.DEVICE_ADDRESS } {
	# Procedure called to validate DEVICE_ADDRESS
	return true
}

proc update_PARAM_VALUE.ENABLE_DIV { PARAM_VALUE.ENABLE_DIV PARAM_VALUE.ENABLE_RV32M } {
	# Procedure called to update ENABLE_DIV when any of the dependent parameters in the arguments change
	
	set ENABLE_DIV ${PARAM_VALUE.ENABLE_DIV}
	set ENABLE_RV32M ${PARAM_VALUE.ENABLE_RV32M}
	set values(ENABLE_RV32M) [get_property value $ENABLE_RV32M]
	set_property value [gen_USERPARAMETER_ENABLE_DIV_VALUE $values(ENABLE_RV32M)] $ENABLE_DIV
}

proc validate_PARAM_VALUE.ENABLE_DIV { PARAM_VALUE.ENABLE_DIV } {
	# Procedure called to validate ENABLE_DIV
	return true
}

proc update_PARAM_VALUE.ENABLE_FAST_MUL { PARAM_VALUE.ENABLE_FAST_MUL PARAM_VALUE.ENABLE_MUL } {
	# Procedure called to update ENABLE_FAST_MUL when any of the dependent parameters in the arguments change
	
	set ENABLE_FAST_MUL ${PARAM_VALUE.ENABLE_FAST_MUL}
	set ENABLE_MUL ${PARAM_VALUE.ENABLE_MUL}
	set values(ENABLE_MUL) [get_property value $ENABLE_MUL]
	if { [gen_USERPARAMETER_ENABLE_FAST_MUL_ENABLEMENT $values(ENABLE_MUL)] } {
		set_property enabled true $ENABLE_FAST_MUL
	} else {
		set_property enabled false $ENABLE_FAST_MUL
	}
}

proc validate_PARAM_VALUE.ENABLE_FAST_MUL { PARAM_VALUE.ENABLE_FAST_MUL } {
	# Procedure called to validate ENABLE_FAST_MUL
	return true
}

proc update_PARAM_VALUE.ENABLE_MUL { PARAM_VALUE.ENABLE_MUL PARAM_VALUE.ENABLE_RV32M } {
	# Procedure called to update ENABLE_MUL when any of the dependent parameters in the arguments change
	
	set ENABLE_MUL ${PARAM_VALUE.ENABLE_MUL}
	set ENABLE_RV32M ${PARAM_VALUE.ENABLE_RV32M}
	set values(ENABLE_RV32M) [get_property value $ENABLE_RV32M]
	set_property value [gen_USERPARAMETER_ENABLE_MUL_VALUE $values(ENABLE_RV32M)] $ENABLE_MUL
}

proc validate_PARAM_VALUE.ENABLE_MUL { PARAM_VALUE.ENABLE_MUL } {
	# Procedure called to validate ENABLE_MUL
	return true
}

proc update_PARAM_VALUE.IMP_SHA2 { PARAM_VALUE.IMP_SHA2 PARAM_VALUE.IMP_MLDSA PARAM_VALUE.IMP_SLHDSA } {
	# Procedure called to update IMP_SHA2 when any of the dependent parameters in the arguments change
	
	set IMP_SHA2 ${PARAM_VALUE.IMP_SHA2}
	set IMP_MLDSA ${PARAM_VALUE.IMP_MLDSA}
	set IMP_SLHDSA ${PARAM_VALUE.IMP_SLHDSA}
	set values(IMP_MLDSA) [get_property value $IMP_MLDSA]
	set values(IMP_SLHDSA) [get_property value $IMP_SLHDSA]
	if { [gen_USERPARAMETER_IMP_SHA2_ENABLEMENT $values(IMP_MLDSA) $values(IMP_SLHDSA)] } {
		set_property enabled true $IMP_SHA2
	} else {
		set_property enabled false $IMP_SHA2
	}
}

proc validate_PARAM_VALUE.IMP_SHA2 { PARAM_VALUE.IMP_SHA2 } {
	# Procedure called to validate IMP_SHA2
	return true
}

proc update_PARAM_VALUE.IMP_SHA3 { PARAM_VALUE.IMP_SHA3 PARAM_VALUE.IMP_MLDSA PARAM_VALUE.IMP_SLHDSA } {
	# Procedure called to update IMP_SHA3 when any of the dependent parameters in the arguments change
	
	set IMP_SHA3 ${PARAM_VALUE.IMP_SHA3}
	set IMP_MLDSA ${PARAM_VALUE.IMP_MLDSA}
	set IMP_SLHDSA ${PARAM_VALUE.IMP_SLHDSA}
	set values(IMP_MLDSA) [get_property value $IMP_MLDSA]
	set values(IMP_SLHDSA) [get_property value $IMP_SLHDSA]
	if { [gen_USERPARAMETER_IMP_SHA3_ENABLEMENT $values(IMP_MLDSA) $values(IMP_SLHDSA)] } {
		set_property enabled true $IMP_SHA3
	} else {
		set_property enabled false $IMP_SHA3
	}
}

proc validate_PARAM_VALUE.IMP_SHA3 { PARAM_VALUE.IMP_SHA3 } {
	# Procedure called to validate IMP_SHA3
	return true
}

proc update_PARAM_VALUE.MEM_BRAM { PARAM_VALUE.MEM_BRAM PARAM_VALUE.MEM_KIB } {
	# Procedure called to update MEM_BRAM when any of the dependent parameters in the arguments change
	
	set MEM_BRAM ${PARAM_VALUE.MEM_BRAM}
	set MEM_KIB ${PARAM_VALUE.MEM_KIB}
	set values(MEM_KIB) [get_property value $MEM_KIB]
	set_property value [gen_USERPARAMETER_MEM_BRAM_VALUE $values(MEM_KIB)] $MEM_BRAM
}

proc validate_PARAM_VALUE.MEM_BRAM { PARAM_VALUE.MEM_BRAM } {
	# Procedure called to validate MEM_BRAM
	return true
}

proc update_PARAM_VALUE.MEM_WORDS { PARAM_VALUE.MEM_WORDS PARAM_VALUE.MEM_KIB } {
	# Procedure called to update MEM_WORDS when any of the dependent parameters in the arguments change
	
	set MEM_WORDS ${PARAM_VALUE.MEM_WORDS}
	set MEM_KIB ${PARAM_VALUE.MEM_KIB}
	set values(MEM_KIB) [get_property value $MEM_KIB]
	set_property value [gen_USERPARAMETER_MEM_WORDS_VALUE $values(MEM_KIB)] $MEM_WORDS
}

proc validate_PARAM_VALUE.MEM_WORDS { PARAM_VALUE.MEM_WORDS } {
	# Procedure called to validate MEM_WORDS
	return true
}

proc update_PARAM_VALUE.PROGADDR_IRQ { PARAM_VALUE.PROGADDR_IRQ PARAM_VALUE.ENABLE_IRQ } {
	# Procedure called to update PROGADDR_IRQ when any of the dependent parameters in the arguments change
	
	set PROGADDR_IRQ ${PARAM_VALUE.PROGADDR_IRQ}
	set ENABLE_IRQ ${PARAM_VALUE.ENABLE_IRQ}
	set values(ENABLE_IRQ) [get_property value $ENABLE_IRQ]
	if { [gen_USERPARAMETER_PROGADDR_IRQ_ENABLEMENT $values(ENABLE_IRQ)] } {
		set_property enabled true $PROGADDR_IRQ
	} else {
		set_property enabled false $PROGADDR_IRQ
	}
}

proc validate_PARAM_VALUE.PROGADDR_IRQ { PARAM_VALUE.PROGADDR_IRQ } {
	# Procedure called to validate PROGADDR_IRQ
	return true
}

proc update_PARAM_VALUE.TOTAL_MEM { PARAM_VALUE.TOTAL_MEM PARAM_VALUE.DEVICE } {
	# Procedure called to update TOTAL_MEM when any of the dependent parameters in the arguments change
	
	set TOTAL_MEM ${PARAM_VALUE.TOTAL_MEM}
	set DEVICE ${PARAM_VALUE.DEVICE}
	set values(DEVICE) [get_property value $DEVICE]
	set_property value [gen_USERPARAMETER_TOTAL_MEM_VALUE $values(DEVICE)] $TOTAL_MEM
}

proc validate_PARAM_VALUE.TOTAL_MEM { PARAM_VALUE.TOTAL_MEM } {
	# Procedure called to validate TOTAL_MEM
	return true
}

proc update_PARAM_VALUE.TRNG_MEM_BRAM { PARAM_VALUE.TRNG_MEM_BRAM PARAM_VALUE.TRNG_MEM_KIB } {
	# Procedure called to update TRNG_MEM_BRAM when any of the dependent parameters in the arguments change
	
	set TRNG_MEM_BRAM ${PARAM_VALUE.TRNG_MEM_BRAM}
	set TRNG_MEM_KIB ${PARAM_VALUE.TRNG_MEM_KIB}
	set values(TRNG_MEM_KIB) [get_property value $TRNG_MEM_KIB]
	set_property value [gen_USERPARAMETER_TRNG_MEM_BRAM_VALUE $values(TRNG_MEM_KIB)] $TRNG_MEM_BRAM
}

proc validate_PARAM_VALUE.TRNG_MEM_BRAM { PARAM_VALUE.TRNG_MEM_BRAM } {
	# Procedure called to validate TRNG_MEM_BRAM
	return true
}

proc update_PARAM_VALUE.TRNG_MEM_KIB { PARAM_VALUE.TRNG_MEM_KIB PARAM_VALUE.IMP_TRNG } {
	# Procedure called to update TRNG_MEM_KIB when any of the dependent parameters in the arguments change
	
	set TRNG_MEM_KIB ${PARAM_VALUE.TRNG_MEM_KIB}
	set IMP_TRNG ${PARAM_VALUE.IMP_TRNG}
	set values(IMP_TRNG) [get_property value $IMP_TRNG]
	if { [gen_USERPARAMETER_TRNG_MEM_KIB_ENABLEMENT $values(IMP_TRNG)] } {
		set_property enabled true $TRNG_MEM_KIB
	} else {
		set_property enabled false $TRNG_MEM_KIB
	}
}

proc validate_PARAM_VALUE.TRNG_MEM_KIB { PARAM_VALUE.TRNG_MEM_KIB } {
	# Procedure called to validate TRNG_MEM_KIB
	return true
}

proc update_PARAM_VALUE.TRNG_MEM_WORDS { PARAM_VALUE.TRNG_MEM_WORDS PARAM_VALUE.TRNG_MEM_KIB } {
	# Procedure called to update TRNG_MEM_WORDS when any of the dependent parameters in the arguments change
	
	set TRNG_MEM_WORDS ${PARAM_VALUE.TRNG_MEM_WORDS}
	set TRNG_MEM_KIB ${PARAM_VALUE.TRNG_MEM_KIB}
	set values(TRNG_MEM_KIB) [get_property value $TRNG_MEM_KIB]
	set_property value [gen_USERPARAMETER_TRNG_MEM_WORDS_VALUE $values(TRNG_MEM_KIB)] $TRNG_MEM_WORDS
}

proc validate_PARAM_VALUE.TRNG_MEM_WORDS { PARAM_VALUE.TRNG_MEM_WORDS } {
	# Procedure called to validate TRNG_MEM_WORDS
	return true
}

proc update_PARAM_VALUE.TRNG_SIZE { PARAM_VALUE.TRNG_SIZE PARAM_VALUE.TRNG_MEM_KIB } {
	# Procedure called to update TRNG_SIZE when any of the dependent parameters in the arguments change
	
	set TRNG_SIZE ${PARAM_VALUE.TRNG_SIZE}
	set TRNG_MEM_KIB ${PARAM_VALUE.TRNG_MEM_KIB}
	set values(TRNG_MEM_KIB) [get_property value $TRNG_MEM_KIB]
	set_property value [gen_USERPARAMETER_TRNG_SIZE_VALUE $values(TRNG_MEM_KIB)] $TRNG_SIZE
}

proc validate_PARAM_VALUE.TRNG_SIZE { PARAM_VALUE.TRNG_SIZE } {
	# Procedure called to validate TRNG_SIZE
	return true
}

proc update_PARAM_VALUE.BARREL_SHIFTER { PARAM_VALUE.BARREL_SHIFTER } {
	# Procedure called to update BARREL_SHIFTER when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.BARREL_SHIFTER { PARAM_VALUE.BARREL_SHIFTER } {
	# Procedure called to validate BARREL_SHIFTER
	return true
}

proc update_PARAM_VALUE.DEVICE { PARAM_VALUE.DEVICE } {
	# Procedure called to update DEVICE when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.DEVICE { PARAM_VALUE.DEVICE } {
	# Procedure called to validate DEVICE
	return true
}

proc update_PARAM_VALUE.ENABLE_COMPRESSED { PARAM_VALUE.ENABLE_COMPRESSED } {
	# Procedure called to update ENABLE_COMPRESSED when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.ENABLE_COMPRESSED { PARAM_VALUE.ENABLE_COMPRESSED } {
	# Procedure called to validate ENABLE_COMPRESSED
	return true
}

proc update_PARAM_VALUE.ENABLE_IRQ { PARAM_VALUE.ENABLE_IRQ } {
	# Procedure called to update ENABLE_IRQ when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.ENABLE_IRQ { PARAM_VALUE.ENABLE_IRQ } {
	# Procedure called to validate ENABLE_IRQ
	return true
}

proc update_PARAM_VALUE.ENABLE_RV32I { PARAM_VALUE.ENABLE_RV32I } {
	# Procedure called to update ENABLE_RV32I when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.ENABLE_RV32I { PARAM_VALUE.ENABLE_RV32I } {
	# Procedure called to validate ENABLE_RV32I
	return true
}

proc update_PARAM_VALUE.ENABLE_RV32M { PARAM_VALUE.ENABLE_RV32M } {
	# Procedure called to update ENABLE_RV32M when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.ENABLE_RV32M { PARAM_VALUE.ENABLE_RV32M } {
	# Procedure called to validate ENABLE_RV32M
	return true
}

proc update_PARAM_VALUE.IMP_AES { PARAM_VALUE.IMP_AES } {
	# Procedure called to update IMP_AES when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.IMP_AES { PARAM_VALUE.IMP_AES } {
	# Procedure called to validate IMP_AES
	return true
}

proc update_PARAM_VALUE.IMP_EDDSA { PARAM_VALUE.IMP_EDDSA } {
	# Procedure called to update IMP_EDDSA when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.IMP_EDDSA { PARAM_VALUE.IMP_EDDSA } {
	# Procedure called to validate IMP_EDDSA
	return true
}

proc update_PARAM_VALUE.IMP_I2C { PARAM_VALUE.IMP_I2C } {
	# Procedure called to update IMP_I2C when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.IMP_I2C { PARAM_VALUE.IMP_I2C } {
	# Procedure called to validate IMP_I2C
	return true
}

proc update_PARAM_VALUE.IMP_MLDSA { PARAM_VALUE.IMP_MLDSA } {
	# Procedure called to update IMP_MLDSA when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.IMP_MLDSA { PARAM_VALUE.IMP_MLDSA } {
	# Procedure called to validate IMP_MLDSA
	return true
}

proc update_PARAM_VALUE.IMP_MLKEM { PARAM_VALUE.IMP_MLKEM } {
	# Procedure called to update IMP_MLKEM when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.IMP_MLKEM { PARAM_VALUE.IMP_MLKEM } {
	# Procedure called to validate IMP_MLKEM
	return true
}

proc update_PARAM_VALUE.IMP_SLHDSA { PARAM_VALUE.IMP_SLHDSA } {
	# Procedure called to update IMP_SLHDSA when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.IMP_SLHDSA { PARAM_VALUE.IMP_SLHDSA } {
	# Procedure called to validate IMP_SLHDSA
	return true
}

proc update_PARAM_VALUE.IMP_TRNG { PARAM_VALUE.IMP_TRNG } {
	# Procedure called to update IMP_TRNG when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.IMP_TRNG { PARAM_VALUE.IMP_TRNG } {
	# Procedure called to validate IMP_TRNG
	return true
}

proc update_PARAM_VALUE.IMP_X25519 { PARAM_VALUE.IMP_X25519 } {
	# Procedure called to update IMP_X25519 when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.IMP_X25519 { PARAM_VALUE.IMP_X25519 } {
	# Procedure called to validate IMP_X25519
	return true
}

proc update_PARAM_VALUE.MEM_KIB { PARAM_VALUE.MEM_KIB } {
	# Procedure called to update MEM_KIB when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.MEM_KIB { PARAM_VALUE.MEM_KIB } {
	# Procedure called to validate MEM_KIB
	return true
}

proc update_PARAM_VALUE.PERIPHERALS_BASE_ADDR { PARAM_VALUE.PERIPHERALS_BASE_ADDR } {
	# Procedure called to update PERIPHERALS_BASE_ADDR when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.PERIPHERALS_BASE_ADDR { PARAM_VALUE.PERIPHERALS_BASE_ADDR } {
	# Procedure called to validate PERIPHERALS_BASE_ADDR
	return true
}

proc update_PARAM_VALUE.PROGADDR_RESET { PARAM_VALUE.PROGADDR_RESET } {
	# Procedure called to update PROGADDR_RESET when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.PROGADDR_RESET { PARAM_VALUE.PROGADDR_RESET } {
	# Procedure called to validate PROGADDR_RESET
	return true
}

proc update_PARAM_VALUE.SLH_KECCAK_BASE_ADDR { PARAM_VALUE.SLH_KECCAK_BASE_ADDR } {
	# Procedure called to update SLH_KECCAK_BASE_ADDR when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.SLH_KECCAK_BASE_ADDR { PARAM_VALUE.SLH_KECCAK_BASE_ADDR } {
	# Procedure called to validate SLH_KECCAK_BASE_ADDR
	return true
}

proc update_PARAM_VALUE.SLH_SHA256_BASE_ADDR { PARAM_VALUE.SLH_SHA256_BASE_ADDR } {
	# Procedure called to update SLH_SHA256_BASE_ADDR when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.SLH_SHA256_BASE_ADDR { PARAM_VALUE.SLH_SHA256_BASE_ADDR } {
	# Procedure called to validate SLH_SHA256_BASE_ADDR
	return true
}

proc update_PARAM_VALUE.SLH_SHA512_BASE_ADDR { PARAM_VALUE.SLH_SHA512_BASE_ADDR } {
	# Procedure called to update SLH_SHA512_BASE_ADDR when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.SLH_SHA512_BASE_ADDR { PARAM_VALUE.SLH_SHA512_BASE_ADDR } {
	# Procedure called to validate SLH_SHA512_BASE_ADDR
	return true
}

proc update_PARAM_VALUE.TWO_CYCLE_ALU { PARAM_VALUE.TWO_CYCLE_ALU } {
	# Procedure called to update TWO_CYCLE_ALU when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.TWO_CYCLE_ALU { PARAM_VALUE.TWO_CYCLE_ALU } {
	# Procedure called to validate TWO_CYCLE_ALU
	return true
}

proc update_PARAM_VALUE.TWO_CYCLE_COMPARE { PARAM_VALUE.TWO_CYCLE_COMPARE } {
	# Procedure called to update TWO_CYCLE_COMPARE when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.TWO_CYCLE_COMPARE { PARAM_VALUE.TWO_CYCLE_COMPARE } {
	# Procedure called to validate TWO_CYCLE_COMPARE
	return true
}


proc update_MODELPARAM_VALUE.BARREL_SHIFTER { MODELPARAM_VALUE.BARREL_SHIFTER PARAM_VALUE.BARREL_SHIFTER } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.BARREL_SHIFTER}] ${MODELPARAM_VALUE.BARREL_SHIFTER}
}

proc update_MODELPARAM_VALUE.ENABLE_MUL { MODELPARAM_VALUE.ENABLE_MUL PARAM_VALUE.ENABLE_MUL } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.ENABLE_MUL}] ${MODELPARAM_VALUE.ENABLE_MUL}
}

proc update_MODELPARAM_VALUE.ENABLE_DIV { MODELPARAM_VALUE.ENABLE_DIV PARAM_VALUE.ENABLE_DIV } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.ENABLE_DIV}] ${MODELPARAM_VALUE.ENABLE_DIV}
}

proc update_MODELPARAM_VALUE.ENABLE_FAST_MUL { MODELPARAM_VALUE.ENABLE_FAST_MUL PARAM_VALUE.ENABLE_FAST_MUL } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.ENABLE_FAST_MUL}] ${MODELPARAM_VALUE.ENABLE_FAST_MUL}
}

proc update_MODELPARAM_VALUE.ENABLE_COMPRESSED { MODELPARAM_VALUE.ENABLE_COMPRESSED PARAM_VALUE.ENABLE_COMPRESSED } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.ENABLE_COMPRESSED}] ${MODELPARAM_VALUE.ENABLE_COMPRESSED}
}

proc update_MODELPARAM_VALUE.ENABLE_IRQ { MODELPARAM_VALUE.ENABLE_IRQ PARAM_VALUE.ENABLE_IRQ } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.ENABLE_IRQ}] ${MODELPARAM_VALUE.ENABLE_IRQ}
}

proc update_MODELPARAM_VALUE.TWO_CYCLE_COMPARE { MODELPARAM_VALUE.TWO_CYCLE_COMPARE PARAM_VALUE.TWO_CYCLE_COMPARE } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.TWO_CYCLE_COMPARE}] ${MODELPARAM_VALUE.TWO_CYCLE_COMPARE}
}

proc update_MODELPARAM_VALUE.TWO_CYCLE_ALU { MODELPARAM_VALUE.TWO_CYCLE_ALU PARAM_VALUE.TWO_CYCLE_ALU } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.TWO_CYCLE_ALU}] ${MODELPARAM_VALUE.TWO_CYCLE_ALU}
}

proc update_MODELPARAM_VALUE.MEM_WORDS { MODELPARAM_VALUE.MEM_WORDS PARAM_VALUE.MEM_WORDS } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.MEM_WORDS}] ${MODELPARAM_VALUE.MEM_WORDS}
}

proc update_MODELPARAM_VALUE.PROGADDR_RESET { MODELPARAM_VALUE.PROGADDR_RESET PARAM_VALUE.PROGADDR_RESET } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.PROGADDR_RESET}] ${MODELPARAM_VALUE.PROGADDR_RESET}
}

proc update_MODELPARAM_VALUE.PROGADDR_IRQ { MODELPARAM_VALUE.PROGADDR_IRQ PARAM_VALUE.PROGADDR_IRQ } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.PROGADDR_IRQ}] ${MODELPARAM_VALUE.PROGADDR_IRQ}
}

proc update_MODELPARAM_VALUE.PERIPHERALS_BASE_ADDR { MODELPARAM_VALUE.PERIPHERALS_BASE_ADDR PARAM_VALUE.PERIPHERALS_BASE_ADDR } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.PERIPHERALS_BASE_ADDR}] ${MODELPARAM_VALUE.PERIPHERALS_BASE_ADDR}
}

proc update_MODELPARAM_VALUE.SLH_KECCAK_BASE_ADDR { MODELPARAM_VALUE.SLH_KECCAK_BASE_ADDR PARAM_VALUE.SLH_KECCAK_BASE_ADDR } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.SLH_KECCAK_BASE_ADDR}] ${MODELPARAM_VALUE.SLH_KECCAK_BASE_ADDR}
}

proc update_MODELPARAM_VALUE.SLH_SHA256_BASE_ADDR { MODELPARAM_VALUE.SLH_SHA256_BASE_ADDR PARAM_VALUE.SLH_SHA256_BASE_ADDR } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.SLH_SHA256_BASE_ADDR}] ${MODELPARAM_VALUE.SLH_SHA256_BASE_ADDR}
}

proc update_MODELPARAM_VALUE.SLH_SHA512_BASE_ADDR { MODELPARAM_VALUE.SLH_SHA512_BASE_ADDR PARAM_VALUE.SLH_SHA512_BASE_ADDR } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.SLH_SHA512_BASE_ADDR}] ${MODELPARAM_VALUE.SLH_SHA512_BASE_ADDR}
}

proc update_MODELPARAM_VALUE.IMP_SHA2 { MODELPARAM_VALUE.IMP_SHA2 PARAM_VALUE.IMP_SHA2 } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.IMP_SHA2}] ${MODELPARAM_VALUE.IMP_SHA2}
}

proc update_MODELPARAM_VALUE.IMP_SHA3 { MODELPARAM_VALUE.IMP_SHA3 PARAM_VALUE.IMP_SHA3 } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.IMP_SHA3}] ${MODELPARAM_VALUE.IMP_SHA3}
}

proc update_MODELPARAM_VALUE.IMP_EDDSA { MODELPARAM_VALUE.IMP_EDDSA PARAM_VALUE.IMP_EDDSA } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.IMP_EDDSA}] ${MODELPARAM_VALUE.IMP_EDDSA}
}

proc update_MODELPARAM_VALUE.IMP_X25519 { MODELPARAM_VALUE.IMP_X25519 PARAM_VALUE.IMP_X25519 } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.IMP_X25519}] ${MODELPARAM_VALUE.IMP_X25519}
}

proc update_MODELPARAM_VALUE.IMP_AES { MODELPARAM_VALUE.IMP_AES PARAM_VALUE.IMP_AES } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.IMP_AES}] ${MODELPARAM_VALUE.IMP_AES}
}

proc update_MODELPARAM_VALUE.IMP_MLKEM { MODELPARAM_VALUE.IMP_MLKEM PARAM_VALUE.IMP_MLKEM } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.IMP_MLKEM}] ${MODELPARAM_VALUE.IMP_MLKEM}
}

proc update_MODELPARAM_VALUE.IMP_TRNG { MODELPARAM_VALUE.IMP_TRNG PARAM_VALUE.IMP_TRNG } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.IMP_TRNG}] ${MODELPARAM_VALUE.IMP_TRNG}
}

proc update_MODELPARAM_VALUE.IMP_MLDSA { MODELPARAM_VALUE.IMP_MLDSA PARAM_VALUE.IMP_MLDSA } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.IMP_MLDSA}] ${MODELPARAM_VALUE.IMP_MLDSA}
}

proc update_MODELPARAM_VALUE.IMP_SLHDSA { MODELPARAM_VALUE.IMP_SLHDSA PARAM_VALUE.IMP_SLHDSA } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.IMP_SLHDSA}] ${MODELPARAM_VALUE.IMP_SLHDSA}
}

proc update_MODELPARAM_VALUE.TRNG_SIZE { MODELPARAM_VALUE.TRNG_SIZE PARAM_VALUE.TRNG_SIZE } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.TRNG_SIZE}] ${MODELPARAM_VALUE.TRNG_SIZE}
}

proc update_MODELPARAM_VALUE.IMP_I2C { MODELPARAM_VALUE.IMP_I2C PARAM_VALUE.IMP_I2C } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.IMP_I2C}] ${MODELPARAM_VALUE.IMP_I2C}
}

proc update_MODELPARAM_VALUE.DEVICE_ADDRESS { MODELPARAM_VALUE.DEVICE_ADDRESS PARAM_VALUE.DEVICE_ADDRESS } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.DEVICE_ADDRESS}] ${MODELPARAM_VALUE.DEVICE_ADDRESS}
}

proc update_MODELPARAM_VALUE.C_S00_AXI_DATA_WIDTH { MODELPARAM_VALUE.C_S00_AXI_DATA_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	# WARNING: There is no corresponding user parameter named "C_S00_AXI_DATA_WIDTH". Setting updated value from the model parameter.
set_property value 64 ${MODELPARAM_VALUE.C_S00_AXI_DATA_WIDTH}
}

proc update_MODELPARAM_VALUE.C_S00_AXI_ADDR_WIDTH { MODELPARAM_VALUE.C_S00_AXI_ADDR_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	# WARNING: There is no corresponding user parameter named "C_S00_AXI_ADDR_WIDTH". Setting updated value from the model parameter.
set_property value 5 ${MODELPARAM_VALUE.C_S00_AXI_ADDR_WIDTH}
}

